self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "8e604778f43af706b4b7163b03f8e05a",
    "url": "/index.html"
  },
  {
    "revision": "1c9b5166d9c532833946",
    "url": "/static/css/2.6326594c.chunk.css"
  },
  {
    "revision": "3e862b4ab9ba4a23295f",
    "url": "/static/css/main.abf7e7b7.chunk.css"
  },
  {
    "revision": "1c9b5166d9c532833946",
    "url": "/static/js/2.2d20fc8b.chunk.js"
  },
  {
    "revision": "570d362d673dab785e62d2b8563e1118",
    "url": "/static/js/2.2d20fc8b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "3e862b4ab9ba4a23295f",
    "url": "/static/js/main.9a1c6c83.chunk.js"
  },
  {
    "revision": "8b5a996c4b3319ce4ba1",
    "url": "/static/js/runtime-main.9c433980.js"
  },
  {
    "revision": "0e49c50e5ad69f331f318c0110ba8511",
    "url": "/static/media/gluko.0e49c50e.png"
  },
  {
    "revision": "8e06ddbdeb462bd39f013a176dd71116",
    "url": "/static/media/grS.8e06ddbd.png"
  },
  {
    "revision": "b9dd17bf67e818c9e0b6280b89cb8a73",
    "url": "/static/media/perCarb.b9dd17bf.png"
  },
  {
    "revision": "de50c7bcbd8c13493991d486b8f2691d",
    "url": "/static/media/perCarb.de50c7bc.svg"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  },
  {
    "revision": "6cc95cae6229631c3bd12f13132d5fde",
    "url": "/static/media/redIn.6cc95cae.png"
  }
]);