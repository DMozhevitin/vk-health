self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "fc958f776baad334ed8db855d5c45b2f",
    "url": "/index.html"
  },
  {
    "revision": "7d95e3ae785ff7bdaf7e",
    "url": "/static/css/2.6326594c.chunk.css"
  },
  {
    "revision": "c13ba1e815550026a67b",
    "url": "/static/css/main.d7b9dd84.chunk.css"
  },
  {
    "revision": "7d95e3ae785ff7bdaf7e",
    "url": "/static/js/2.47d15d98.chunk.js"
  },
  {
    "revision": "570d362d673dab785e62d2b8563e1118",
    "url": "/static/js/2.47d15d98.chunk.js.LICENSE.txt"
  },
  {
    "revision": "c13ba1e815550026a67b",
    "url": "/static/js/main.e916041b.chunk.js"
  },
  {
    "revision": "8b5a996c4b3319ce4ba1",
    "url": "/static/js/runtime-main.9c433980.js"
  },
  {
    "revision": "368ffd95244e8c2f5acb4eccd1b249b3",
    "url": "/static/media/blood-drop.368ffd95.svg"
  },
  {
    "revision": "c586a6cf6b3c3d56d535e373a7a52a9f",
    "url": "/static/media/dn.c586a6cf.png"
  },
  {
    "revision": "2c5ddeb45f98a604195fdca0ad8e88e8",
    "url": "/static/media/getStat.2c5ddeb4.png"
  },
  {
    "revision": "ee364532bcd4f974a53133bce191339d",
    "url": "/static/media/glikIndex.ee364532.png"
  },
  {
    "revision": "0e49c50e5ad69f331f318c0110ba8511",
    "url": "/static/media/gluko.0e49c50e.png"
  },
  {
    "revision": "8e06ddbdeb462bd39f013a176dd71116",
    "url": "/static/media/grS.8e06ddbd.png"
  },
  {
    "revision": "b9dd17bf67e818c9e0b6280b89cb8a73",
    "url": "/static/media/perCarb.b9dd17bf.png"
  },
  {
    "revision": "de50c7bcbd8c13493991d486b8f2691d",
    "url": "/static/media/perCarb.de50c7bc.svg"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  },
  {
    "revision": "6cc95cae6229631c3bd12f13132d5fde",
    "url": "/static/media/redIn.6cc95cae.png"
  }
]);