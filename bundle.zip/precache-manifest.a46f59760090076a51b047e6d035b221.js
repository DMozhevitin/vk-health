self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "5998063d2bae563bf993fe2d8253dc47",
    "url": "/index.html"
  },
  {
    "revision": "7b888e178ae111cb2464",
    "url": "/static/css/2.6326594c.chunk.css"
  },
  {
    "revision": "630b6c8a7494811c8f57",
    "url": "/static/css/main.9a1be665.chunk.css"
  },
  {
    "revision": "7b888e178ae111cb2464",
    "url": "/static/js/2.a8d4e626.chunk.js"
  },
  {
    "revision": "570d362d673dab785e62d2b8563e1118",
    "url": "/static/js/2.a8d4e626.chunk.js.LICENSE.txt"
  },
  {
    "revision": "630b6c8a7494811c8f57",
    "url": "/static/js/main.12648764.chunk.js"
  },
  {
    "revision": "8b5a996c4b3319ce4ba1",
    "url": "/static/js/runtime-main.9c433980.js"
  },
  {
    "revision": "0e49c50e5ad69f331f318c0110ba8511",
    "url": "/static/media/gluko.0e49c50e.png"
  },
  {
    "revision": "8e06ddbdeb462bd39f013a176dd71116",
    "url": "/static/media/grS.8e06ddbd.png"
  },
  {
    "revision": "b9dd17bf67e818c9e0b6280b89cb8a73",
    "url": "/static/media/perCarb.b9dd17bf.png"
  },
  {
    "revision": "de50c7bcbd8c13493991d486b8f2691d",
    "url": "/static/media/perCarb.de50c7bc.svg"
  },
  {
    "revision": "4e1ec8403d903dc514271d7328fbdeb3",
    "url": "/static/media/persik.4e1ec840.png"
  },
  {
    "revision": "6cc95cae6229631c3bd12f13132d5fde",
    "url": "/static/media/redIn.6cc95cae.png"
  }
]);